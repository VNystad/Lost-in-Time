//
// Created by Vetle Norman on 15/11/16.
//

#ifndef LOST_IN_TIME_CAMERA_H
#define LOST_IN_TIME_CAMERA_H

class Camera
{
public:

    const int PositionX = 400;
    const int PositionY = 600;
};

#endif //LOST_IN_TIME_CAMERA_H
