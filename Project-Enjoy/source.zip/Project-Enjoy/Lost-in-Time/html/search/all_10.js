var searchData=
[
  ['redhealthframe',['redHealthFrame',['../classHealth.html#a437bfdf8c9420a54cc79e034bc7d0f28',1,'Health']]],
  ['redhealthsprite',['redHealthSprite',['../classHealth.html#a81427f31d58c914e2d2ad0a28261288d',1,'Health']]],
  ['redhealthtexture',['redHealthTexture',['../classHealth.html#ab08ff98832c9ac6297a803fdbc6a69cd',1,'Health']]],
  ['regularhorslowdown',['regularhorslowdown',['../classAI.html#a021f46f3eb1d76607a5a22bdcd296d11',1,'AI::regularhorslowdown()'],['../classPlayerObject.html#a925251c105714f50f384a9ab4039a961',1,'PlayerObject::regularhorslowdown()'],['../classPrincessObject.html#a093c3d3c7b812fb303cd8472ee06e892',1,'PrincessObject::regularhorslowdown()']]],
  ['reset2originalx',['Reset2OriginalX',['../classAI.html#a9e60e3da7ae96c1a7bc5dbff38c4128e',1,'AI::Reset2OriginalX()'],['../classPlayerObject.html#a9dd4494cfaeb6dfa74b84ad19df5d650',1,'PlayerObject::Reset2OriginalX()'],['../classPrincessObject.html#a49e1e54a9bf9edcc265910a8ed745ee8',1,'PrincessObject::Reset2OriginalX()']]],
  ['reset2originaly',['Reset2OriginalY',['../classAI.html#ac0f90e7b4065125014f476b2132e61ed',1,'AI::Reset2OriginalY()'],['../classPlayerObject.html#af545457981fc51138ba2c735bdeecb31',1,'PlayerObject::Reset2OriginalY()'],['../classPrincessObject.html#a9f20547ef95b7a485acaa384d8be8ba7',1,'PrincessObject::Reset2OriginalY()']]],
  ['resethealth',['ResetHealth',['../classHealth.html#a1e7a4804607edece9a4711a0da254f75',1,'Health']]],
  ['resumegame',['resumeGame',['../classTestApp.html#a84f09383791a4d24088e5fe4b4cd6542',1,'TestApp']]],
  ['resumegameselected',['resumeGameSelected',['../classTestApp.html#a8caa47ef20c8711b1b89c9b82ab1202e',1,'TestApp']]],
  ['resumegameselectedsprite',['resumeGameSelectedSprite',['../classTestApp.html#ab648e1b4ef3f657ca152176709c17ccc',1,'TestApp']]],
  ['resumegamesprite',['resumeGameSprite',['../classTestApp.html#a9d080e34bbede4ba5e6c6423ef34fd91',1,'TestApp']]],
  ['rightkey',['rightKey',['../classPrincessObject.html#a9023c2cc21ae3bb18772592adaeb774d',1,'PrincessObject::rightKey()'],['../classAI.html#afd8bf97dd365a456af724aade73129fb',1,'AI::rightkey()']]],
  ['roofed',['Roofed',['../classPhysics.html#ad95b0cb8eec16acd74177a8d79eb0850',1,'Physics']]],
  ['running',['running',['../classMachine.html#aaf4949e30c3e33602e4082c9739d3e37',1,'Machine']]]
];
