var searchData=
[
  ['updatehealth',['UpdateHealth',['../classHealth.html#a364947262ddd1a1a318b470468742b08',1,'Health']]],
  ['upkey',['upkey',['../classAI.html#a1bde8ebcfb666d83ffb7e71993bf06fc',1,'AI::upkey()'],['../classPrincessObject.html#ad9b1f2960b134b902515903b9a3b5a33',1,'PrincessObject::upkey()']]]
];
