var searchData=
[
  ['x',['x',['../classHealth.html#aceaf91c7887b0e3f9d94d91909c3b231',1,'Health::x()'],['../structTileSize.html#add80f453cede5e47fc0c598c1660e174',1,'TileSize::x()'],['../classSprite.html#ab36028dcefdd4bf024c52c8d9519a283',1,'Sprite::x()']]],
  ['xcoord',['xCoord',['../classTile.html#ac23f889a0d8504d51fd58cffeb439aea',1,'Tile']]]
];
