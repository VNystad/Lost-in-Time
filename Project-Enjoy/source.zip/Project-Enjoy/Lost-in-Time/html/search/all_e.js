var searchData=
[
  ['object',['Object',['../classObject.html',1,'Object'],['../classObject.html#a0c2b99c7e193a7f310c4df5467040999',1,'Object::Object()']]],
  ['object_2ecpp',['object.cpp',['../object_8cpp.html',1,'']]],
  ['object_2eh',['object.h',['../object_8h.html',1,'']]],
  ['objects',['objects',['../classTestApp.html#a8fbfb637e9e690ef9179cce7151c86c5',1,'TestApp']]],
  ['originalhealth',['originalhealth',['../classHealth.html#aee066fa0c8d1ad09e1266882c258d006',1,'Health']]],
  ['originalx',['OriginalX',['../classAI.html#a3399d587364d2fef3e4a176ecdc294cc',1,'AI::OriginalX()'],['../classPlayerObject.html#a2171b8772f4959d8a217aa0269df6250',1,'PlayerObject::OriginalX()'],['../classPrincessObject.html#a42095ab9d816790313c5309402ee3d63',1,'PrincessObject::OriginalX()']]],
  ['originaly',['OriginalY',['../classAI.html#a652d91a3a0b53d7919f6a2b02e301f26',1,'AI::OriginalY()'],['../classPlayerObject.html#ac0a91ffa7a56cacd15b49052addacbda',1,'PlayerObject::OriginalY()'],['../classPrincessObject.html#a46a4701d6804ce96d10507e5f99579d8',1,'PrincessObject::OriginalY()']]],
  ['origjumpspeed',['origjumpspeed',['../classAI.html#ac7bc723979294e5fe5d7438713229473',1,'AI::origjumpspeed()'],['../classPlayerObject.html#a352711ae9a2f07845e69a6a345b2e341',1,'PlayerObject::origjumpspeed()'],['../classPrincessObject.html#a0d83126222c2eb30007a8731cc8f9dc1',1,'PrincessObject::origjumpspeed()']]]
];
