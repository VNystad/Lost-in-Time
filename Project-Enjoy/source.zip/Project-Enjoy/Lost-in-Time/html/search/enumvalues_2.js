var searchData=
[
  ['mainmenu',['MAINMENU',['../classMachine.html#a5fb0c119d231dd1bfe1dd2c9ca533520a3287971e79b4dca11067ed287847c1e6',1,'Machine']]]
];
