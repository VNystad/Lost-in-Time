var searchData=
[
  ['reset2originalx',['Reset2OriginalX',['../classAI.html#a9e60e3da7ae96c1a7bc5dbff38c4128e',1,'AI::Reset2OriginalX()'],['../classPlayerObject.html#a9dd4494cfaeb6dfa74b84ad19df5d650',1,'PlayerObject::Reset2OriginalX()'],['../classPrincessObject.html#a49e1e54a9bf9edcc265910a8ed745ee8',1,'PrincessObject::Reset2OriginalX()']]],
  ['reset2originaly',['Reset2OriginalY',['../classAI.html#ac0f90e7b4065125014f476b2132e61ed',1,'AI::Reset2OriginalY()'],['../classPlayerObject.html#af545457981fc51138ba2c735bdeecb31',1,'PlayerObject::Reset2OriginalY()'],['../classPrincessObject.html#a9f20547ef95b7a485acaa384d8be8ba7',1,'PrincessObject::Reset2OriginalY()']]],
  ['resethealth',['ResetHealth',['../classHealth.html#a1e7a4804607edece9a4711a0da254f75',1,'Health']]],
  ['roofed',['Roofed',['../classPhysics.html#ad95b0cb8eec16acd74177a8d79eb0850',1,'Physics']]]
];
