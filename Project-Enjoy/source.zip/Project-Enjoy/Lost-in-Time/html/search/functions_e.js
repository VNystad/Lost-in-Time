var searchData=
[
  ['updatehealth',['UpdateHealth',['../classHealth.html#a364947262ddd1a1a318b470468742b08',1,'Health']]]
];
