var indexSectionsWithContent =
{
  0: "abcdefghijklmnoprstuvwxy~",
  1: "acdfhlmopst",
  2: "js",
  3: "acdfhlmopst",
  4: "acdeghilmoprstuv~",
  5: "abcdefghijklmnoprstuvwxy",
  6: "s",
  7: "glm",
  8: "gm"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends"
};

