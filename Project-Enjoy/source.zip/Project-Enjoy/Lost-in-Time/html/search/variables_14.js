var searchData=
[
  ['victorytext',['victoryText',['../classTestApp.html#a11b6f78ad8d0e5eaf77971cbf8cbe723',1,'TestApp']]],
  ['visiblelifepoints',['visiblelifepoints',['../classHealth.html#af0aaa45a0e5e94a3c22ee96d08514513',1,'Health']]]
];
